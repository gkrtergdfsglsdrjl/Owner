/*
Original code by Dacal --> Modified code by Schnedi.
*/

var Clock = "24h";	       // choose between "12h" or "24h".
var Lang = "ua";	           // choose between "ca", "en", "fr" or "de".