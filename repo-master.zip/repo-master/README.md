# Cydia Repo

Cydia repository

Add this url to Cydia sources to use my repository:

```center
https://gebeto.github.io/repo
```

## [Click to Add repo to Cydia](cydia://url/https://cydia.saurik.com/api/share#?source=https://gebeto.github.io/repo)
[https://gebeto.github.io/repo](https://gebeto.github.io/repo)
